/*
 * ADC.h
 *
 * Created: 2016-04-28 14:03:29
 *  Author: Atomic
 */ 


#ifndef ADC_H_
#define ADC_H_

void ADC_init(void);
uint16_t Read_ADC(uint8_t ADC_Channel);


#endif /* ADC_H_ */