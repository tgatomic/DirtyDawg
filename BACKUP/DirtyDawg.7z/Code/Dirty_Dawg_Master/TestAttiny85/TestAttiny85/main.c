/*
 * TestAttiny85.c
 *
 * Created: 2016-05-09 15:21:59
 * Author : Atomic
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

